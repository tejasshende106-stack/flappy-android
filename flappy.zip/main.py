import pygame
import random

pygame.init()
pygame.mixer.init()

# Load sounds
pygame.mixer.music.load("background.mp3")
pygame.mixer.music.play(-1)
pygame.mixer.music.set_volume(0.5)
game_over_sound = pygame.mixer.Sound("game_over.wav")
flap_sound = pygame.mixer.Sound("flap.wav")

# Screen setup
WIDTH, HEIGHT = 1600, 720
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Flappy Bird")

# Load images
bird_img = pygame.image.load("bird.png").convert_alpha()
bird_img = pygame.transform.scale(bird_img, (40, 40))
background_img = pygame.image.load("background.png").convert()
background_img = pygame.transform.scale(background_img, (WIDTH, HEIGHT))
pipe_img = pygame.image.load("pipe.png").convert_alpha()
pipe_img = pygame.transform.scale(pipe_img, (80, 400))

# Game variables
bird_x = 100
bird_y = HEIGHT // 2
bird_velocity = 0
bird_radius = 20
GRAVITY = 0.5
JUMP_STRENGTH = -10
PIPE_GAP = 200
PIPE_SPEED = 3
pipes = []
score = 0
game_over = False
paused = False
started = False

# Fonts
font = pygame.font.SysFont(None, 48)
button_font = pygame.font.SysFont(None, 36)
countdown_font = pygame.font.SysFont(None, 150)

# Clock
clock = pygame.time.Clock()
FPS = 60

# Pause & Menu Button Setup
pause_button = pygame.Rect(int(WIDTH * 0.98) - 120, 20, 120, 50)
menu_buttons = [
    {"label": "Resume", "action": "resume"},
    {"label": "Restart", "action": "restart"},
    {"label": "Exit", "action": "exit"},
]
menu_button_width = 200
menu_button_height = 60
menu_button_padding = 20
menu_x = WIDTH // 2 - menu_button_width // 2
menu_y = HEIGHT // 2 - (len(menu_buttons) * (menu_button_height + menu_button_padding)) // 2

start_button = pygame.Rect(WIDTH // 2 - 150, HEIGHT // 2 - 40, 300, 80)

def create_pipe():
    top_height = random.randint(50, HEIGHT - PIPE_GAP - 100)
    return {"x": WIDTH, "top": top_height, "bottom": top_height + PIPE_GAP}

def show_countdown():
    for i in range(3, 0, -1):
        screen.blit(background_img, (0, 0))
        text = countdown_font.render(str(i), True, (255, 0, 0))
        screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2 - text.get_height() // 2))
        pygame.display.update()
        pygame.time.delay(1000)

def draw_pause_button():
    pygame.draw.rect(screen, (200, 200, 200), pause_button, border_radius=8)
    text = button_font.render("Pause", True, (0, 0, 0))
    screen.blit(text, (pause_button.x + (pause_button.width - text.get_width()) // 2,
                       pause_button.y + (pause_button.height - text.get_height()) // 2))

def draw_menu():
    for i, btn in enumerate(menu_buttons):
        x = menu_x
        y = menu_y + i * (menu_button_height + menu_button_padding)
        pygame.draw.rect(screen, (180, 180, 180), (x, y, menu_button_width, menu_button_height), border_radius=8)
        label = button_font.render(btn["label"], True, (0, 0, 0))
        screen.blit(label, (x + (menu_button_width - label.get_width()) // 2, y + 15))

def handle_menu_click(pos):
    for i, btn in enumerate(menu_buttons):
        x = menu_x
        y = menu_y + i * (menu_button_height + menu_button_padding)
        if x <= pos[0] <= x + menu_button_width and y <= pos[1] <= y + menu_button_height:
            return btn["action"]
    return None

def draw_start_button():
    pygame.draw.rect(screen, (0, 200, 0), start_button, border_radius=12)
    text = font.render("Start Game", True, (255, 255, 255))
    screen.blit(text, (start_button.x + (start_button.width - text.get_width()) // 2,
                       start_button.y + (start_button.height - text.get_height()) // 2))

running = True
while running:
    clock.tick(FPS)
    screen.blit(background_img, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()

            if not started and start_button.collidepoint(mouse_pos):
                started = True
                pipes = [create_pipe()]
                show_countdown()

            elif game_over:
                bird_y = HEIGHT // 2
                bird_velocity = 0
                pipes = [create_pipe()]
                score = 0
                game_over = False
                paused = False
                show_countdown()

            elif paused:
                action = handle_menu_click(mouse_pos)
                if action == "resume":
                    paused = False
                elif action == "restart":
                    bird_y = HEIGHT // 2
                    bird_velocity = 0
                    pipes = [create_pipe()]
                    score = 0
                    game_over = False
                    paused = False
                    show_countdown()
                elif action == "exit":
                    running = False

            elif pause_button.collidepoint(mouse_pos):
                paused = not paused

            elif not paused:
                bird_velocity = JUMP_STRENGTH
                flap_sound.play()

    if not started:
        draw_start_button()

    elif not paused and not game_over:
        bird_velocity += GRAVITY
        bird_y += bird_velocity
        screen.blit(bird_img, (bird_x - 20, int(bird_y) - 20))

        for pipe in pipes:
            pipe["x"] -= PIPE_SPEED
            top_pipe = pygame.transform.flip(pipe_img, False, True)
            screen.blit(top_pipe, (pipe["x"], pipe["top"] - 400))
            screen.blit(pipe_img, (pipe["x"], pipe["bottom"]))

        if pipes[-1]["x"] < WIDTH - 300:
            pipes.append(create_pipe())

        if pipes[0]["x"] < -80:
            pipes.pop(0)
            score += 1

        for pipe in pipes:
            if pipe["x"] < bird_x + bird_radius < pipe["x"] + 80:
                if bird_y - bird_radius < pipe["top"] or bird_y + bird_radius > pipe["bottom"]:
                    if not game_over:
                        game_over_sound.play()
                        game_over = True
                        paused = False

        if bird_y < 0 or bird_y > HEIGHT:
            if not game_over:
                game_over_sound.play()
                game_over = True
                paused = False

        score_text = font.render(f"Score: {score}", True, (0, 0, 0))
        screen.blit(score_text, (10, 10))

    elif game_over:
        over_text = font.render("Game Over! Tap to Restart", True, (255, 0, 0))
        screen.blit(over_text, (
            WIDTH // 2 - over_text.get_width() // 2,
            HEIGHT // 2 - over_text.get_height() // 2
        ))

    elif paused:
        draw_menu()

    if not game_over and started:
        draw_pause_button()

    pygame.display.update()

pygame.quit()
